
public class test1 {
	
	int cube (int x)
	{
		return x * x * x;
	}

}
