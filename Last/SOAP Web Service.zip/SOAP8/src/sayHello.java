
public class sayHello {
	public String hello (String name)
	{
		return new String ("Hello" + name);
	}

}
